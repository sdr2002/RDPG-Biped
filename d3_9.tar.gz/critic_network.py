import tensorflow as tf
import numpy as np
import math

# Hyper-Parameters
LAYER1_SIZE = 512
LAYER2_SIZE = 512
LAYER3_SIZE = 512

LEARNING_RATE = 1e-3
TAU = 0.01
L2 = 1e-5  # 1e-3 originally

unit_length = 1 # replacement to None in time_length placeholder

class CriticNetwork:
    """docstring for CriticNetwork"""

    def __init__(self, sess, batch_size, state_dim, action_dim, temp_abstract,DIRECTORY):
        self.DIRECTORY = DIRECTORY

        self.sess = sess

        self.state_dim = state_dim
        self.action_dim = action_dim

        self.temp_abstract = temp_abstract
        # self.rnn1_size= RNN1_SIZE
        # self.rnn_layer= RNN_LAYER

        # create behaviour q network
        self.xav = tf.contrib.layers.xavier_initializer()
        self.state_input, self.action_input, self.q_value_output, self.net \
            = self.create_q_network(state_dim, action_dim)#, self.trace_length)

        # create target q network (the same structure with q network)
        self.var_count = len(self.net)
        self.target_state_input, self.target_action_input, self.target_q_value_output, \
        self.target_update_op, self.target_assign_op, self.target_net \
            = self.create_target_q_network(state_dim, action_dim, self.net)#, self.trace_length)

        ###
        self.norm_diff = self.diff(self.net, self.target_net)
        ###

        # define training rules, initialization
        self.create_training_method()
        self.sess.run(tf.global_variables_initializer())
        # update target net
        self.update_target()
        # save & upload
        self.load_network()

    def create_training_method(self):
        # Define training optimizer
        self.y_input = tf.placeholder("float", [None, unit_length, 1])
        self.update_length = tf.placeholder(tf.int32)
        weight_decay = tf.add_n([L2 * tf.nn.l2_loss(var) for var in self.net])
        self.cost = tf.reduce_mean(tf.square(self.y_input - self.q_value_output[:,-self.update_length:,:])) + weight_decay

        self.parameters_gradients = tf.gradients(self.cost, self.net)
        self.grad_norm = tf.reduce_sum([tf.norm(grad) for grad in self.parameters_gradients])
        self.optimizer = tf.train.AdamOptimizer(LEARNING_RATE).apply_gradients(zip(self.parameters_gradients, self.net))

        self.action_gradients = tf.gradients(self.q_value_output, self.action_input)

    def network(self, input_list):
        state_agent, state_ridar, action_input = input_list
        state = tf.concat([state_agent,state_ridar],axis=-1)

        ###1)State embeddings part
        with tf.name_scope('s_emb') as s_emb:
            W1 = tf.get_variable("W_conv1", shape=[1, 24, 1, LAYER1_SIZE], initializer=self.xav)
            b1 = tf.get_variable("b_conv1", shape=[LAYER1_SIZE], initializer=self.xav)
            layer1 = tf.expand_dims(tf.squeeze(\
                tf.nn.relu(tf.nn.bias_add(\
                tf.nn.conv2d(input=tf.expand_dims(state, axis=-1),filter=W1, strides=[1,1,1,1], padding='VALID'),\
                                        bias=b1)),\
                axis=2),axis=-1)

            W2_state = tf.get_variable("W2_state", shape=[1,LAYER1_SIZE,1,LAYER2_SIZE], initializer=self.xav)
            layer2_state = tf.nn.conv2d(input=layer1,filter=W2_state, strides=[1,1,1,1], padding='VALID')

        ###2)Action embeddings part
        with tf.name_scope('a_emb') as a_emb:
            W2_action = tf.get_variable("W2_action", shape=[1,self.action_dim,1,LAYER2_SIZE], initializer=self.xav)
            layer2_action = tf.nn.conv2d(input=tf.expand_dims(action_input,axis=-1), filter=W2_action,strides=[1,1,1,1], padding='VALID')

        ###3)State-Action embeddings part
        with tf.name_scope('sa_emb') as sa_emb:
            b2 = tf.get_variable("b2_state", shape=[LAYER2_SIZE], initializer=self.xav)
            layer2 = tf.expand_dims(tf.squeeze(\
                tf.nn.relu(tf.nn.bias_add(layer2_state+layer2_action,bias=b2)),\
                axis=2),axis=-1)
            timesteps_rep_list = tf.squeeze(layer2,axis=-1)

        ###4) Q-trace generation
        with tf.name_scope('q_gen') as q_gen:
            Wf = tf.get_variable("Wf", shape=[1, LAYER2_SIZE, 1, 1], initializer=self.xav) #shape=[1, 1, LAYER3_SIZE, 1]
            finals = tf.nn.conv2d(input=tf.expand_dims(timesteps_rep_list,-1), filter=Wf,strides=[1,1,1,1], padding='VALID')#input=layer3
            # bf = tf.get_variable("bf", shape=[1], initializer=self.xav)
            # finals = tf.nn.bias_add(\
            #     tf.nn.conv2d(input=tf.expand_dims(timesteps_rep_list,-1), filter=Wf,strides=[1,1,1,1], padding='VALID'),\
            #     bias=bf)#input=layer3

            q_trace = tf.squeeze(finals,axis=2)

        ####Final)Return q-value and network params
        net = [v for v in tf.trainable_variables() if tf.contrib.framework.get_name_scope() in v.name]
        return q_trace, net

        # #### Take the last time-step into account from rnn: not feasible if you optimise with trace of TD errors
        # W3 = tf.Variable(tf.truncated_normal([self.rnn_size, 1], 0., 2e-1))
        # b3 = tf.Variable(tf.random_uniform([1], -3e-2, 3e-2))
        # final = tf.identity(tf.matmul(self.rnn_states[:,-1], W3) + b3)
        # return final, rnn_hidden_cm, [v for v in tf.trainable_variables() if tf.contrib.framework.get_name_scope() in v.name]

    def create_q_network(self, state_dim, action_dim): #, trace_length):
        state_input = tf.placeholder("float", [None, unit_length, state_dim])
        avg_state_input = state_input
        state_agent, state_ridar = tf.split(avg_state_input, [14, 10],axis=2)

        action_input = tf.placeholder("float", [None, unit_length, action_dim])
        avg_action_trace = action_input#tf.concat([action_input,action_last_input],axis=1)

        with tf.variable_scope('critic_behaviour',reuse=False) as cb:
            input_list = [state_agent, state_ridar, avg_action_trace]
            q_value_output, net = self.network(input_list) # q_value_output = tf.identity(tf.matmul(layer2, W3) + b3)

        return state_input, action_input, q_value_output, net

    def create_target_q_network(self, state_dim, action_dim, net):#, trace_length):
        state_input = tf.placeholder("float", [None, None, state_dim])
        avg_state_input = state_input
        state_agent, state_ridar = tf.split(avg_state_input, [14, 10],axis=2)

        action_input = tf.placeholder("float", [None, None, action_dim])
        target_avg_action_trace = action_input

        ema = tf.train.ExponentialMovingAverage(decay=1. - TAU)
        target_update_op = ema.apply(net)

        with tf.variable_scope('critic_target') as ct:
            input_list = [state_agent, state_ridar, target_avg_action_trace]
            q_value_output, target_net = self.network(input_list)#,param_list)

            target_assign_op = [[] for i in range(self.var_count)]
            for i in range(self.var_count):
                target_assign_op[i] = target_net[i].assign(ema.average(net[i]))

        return state_input, action_input, q_value_output, target_update_op, target_assign_op, target_net

    def update_target(self):
        self.sess.run(self.target_update_op)
        for i in range(self.var_count):
            self.sess.run(self.target_assign_op[i])

    def train(self, y_batch, update_length, state_batch, action_batch):
        try:
            _, grad_norm = self.sess.run([self.optimizer,self.grad_norm], feed_dict={
                self.y_input: y_batch,
                self.update_length: update_length,
                self.state_input: state_batch,
                self.action_input: action_batch,
            })
            return grad_norm
        except Exception as e:
            print '?'
            raise

    def gradients(self, update_length, state_batch, action_batch):
        try:
            return self.sess.run(self.action_gradients, feed_dict={
                self.state_input: state_batch,
                self.action_input: action_batch,
            })[0][:,-update_length:,:]
        except Exception as e:
            print '?'

    def target_q_trace(self, state_batch, action_batch):
        q_value_trace = self.sess.run(self.target_q_value_output, feed_dict={
            self.target_state_input: state_batch,
            self.target_action_input: action_batch,
        })#target_s,a
        return q_value_trace[:,-1,:]

    def q_value(self, state_trace, action_trace):#(self, state_batch, action_batch):
        q_value = self.sess.run([self.q_value_output], feed_dict={
            self.state_input: [state_trace],
            self.action_input: [action_trace],
        })
        return q_value[0][0]

    ###
    def diff(self, target, behave):
        diff = 0.
        for param_pair in zip(target, behave):
            diff += tf.norm(tf.subtract(param_pair[0], param_pair[1]))
        return diff

    def get_diff(self):
        return self.sess.run(self.norm_diff)
    ###

    def load_network(self):
        self.saver = tf.train.Saver()
        checkpoint = tf.train.get_checkpoint_state(self.DIRECTORY+'/saved_critic_networks')
        if checkpoint and checkpoint.model_checkpoint_path:
            self.saver.restore(self.sess, checkpoint.model_checkpoint_path)
            print("Successfully loaded:", checkpoint.model_checkpoint_path)
        else:
            print("Could not find old network weights - Critic")

    def save_network(self,episode):
        print('save critic-network...', episode)
        self.saver.save(self.sess, self.DIRECTORY+'/saved_critic_networks/critic-network', global_step = episode)

